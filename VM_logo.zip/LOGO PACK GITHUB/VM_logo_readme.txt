
VictoriaMetrics Logo Usage Guidelines

The provided ZIP file contains three folders with different logo orientations. Each folder includes the following file types:

JPEG: Preview files
PNG: Preview files with transparent background
AI: Adobe Illustrator files

Font:
Font Used: Lato Black
Download here: Lato Font

Color Palette:
Black: #000000
Purple: #4d0e82
Orange: #ff2e00
White: #FFFFFF

Logo Usage Rules:
Only use the Lato Black font as specified.
Maintain sufficient clear space around the logo for visibility.
Do not modify the spacing, alignment, or positioning of design elements.
You may resize the logo as needed, but ensure all proportions remain intact.

Thank you for your cooperation!








