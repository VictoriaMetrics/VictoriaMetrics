
Victoria Metrics Logo

Zip contains 3 folders with different image orientation (main color and inverted version).

Files included in each folder:

2 JPEG Preview files
2 PNG Preview files with transparent background
2 EPS Adobe Illustrator EPS10 files


Logo Usage Guidelines

Font used: 
Lato Black
Lato Regular
https://fonts.google.com/specimen/Lato

Color Palette:
HEX #110f0f https://www.color-hex.com/color/110f0f
HEX #ffffff https://www.color-hex.com/color/ffffff

- Please don't use any other font instead of suggested.
- There should be sufficient clear space around the logo.
- Do not change spacing, alignment, or relative locations of the design elements.
- Do not change the proportions of any of the design elements or the design itself. You    may resize as needed but must retain all proportions.


Thanks for cooperation !

